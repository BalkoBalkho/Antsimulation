#pragma once
#include "Pherenome.h"
#include "World.h"

struct AntCord {
	struct head { int x; int y; };
	struct body { int x; int y; };
	struct stinger { int x; int y; };
	
};

class Ant {
	AntCord POS;

	Pherenome::jobs current_goal;

	

	//namespace life {
	int health; 
	int age;


	int sleepiness;
	int favorite_number;	
	int steps_counter;

	

	//}
	
	void move();
	World::WorldPixel sense();
	void findJob();
	void completeJob();

public :
	void tick(); // Run every game loop.

	
};

class Queen : public Ant {


};

class Colony {
	int id;

};